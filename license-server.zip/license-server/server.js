// ============================================================================
//  Unic Client - Servidor de Licencas (Node.js puro, sem dependencias)
//  Recursos:
//   - Geracao de chaves unicas
//   - Vinculacao 1 device por key (HWID)
//   - Validacao automatica (key + HWID)
//   - Revogar / renovar / expirar
//   - Painel administrativo web (/admin) protegido por token
//   - Armazenamento em arquivo JSON (atomico) + assinatura HMAC nas respostas
//  Uso:
//   ADMIN_TOKEN=suasenha PORT=8090 node server.js
// ============================================================================
'use strict';
const http = require('http');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// ----------------------------------------------------------------------------
// Config (via variaveis de ambiente; tem defaults pra rodar local)
// ----------------------------------------------------------------------------
const PORT        = parseInt(process.env.PORT || '8090', 10);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'troque-este-token-admin';
const SIGN_SECRET = process.env.SIGN_SECRET || 'troque-este-segredo-de-assinatura';
const DB_FILE     = process.env.DB_FILE || path.join(__dirname, 'db.json');
const MAX_DEVICES = 1; // 1 device por key

// ----------------------------------------------------------------------------
// "Banco" em arquivo JSON  { keys: { <KEY>: {created, expiresAt, hwid, activatedAt, revoked, note} } }
// ----------------------------------------------------------------------------
let DB = { keys: {} };
function loadDB() {
  try { DB = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); if (!DB.keys) DB.keys = {}; }
  catch (e) { DB = { keys: {} }; }
}
function saveDB() {
  const tmp = DB_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(DB, null, 2));
  fs.renameSync(tmp, DB_FILE); // escrita atomica
}
loadDB();

// ----------------------------------------------------------------------------
// Util
// ----------------------------------------------------------------------------
const now = () => Date.now();
const days = (n) => n * 24 * 60 * 60 * 1000;
function sign(obj) {
  const body = JSON.stringify(obj);
  const mac = crypto.createHmac('sha256', SIGN_SECRET).update(body).digest('hex').slice(0, 24);
  return { ...obj, sig: mac };
}
function genKey() {
  // 15 bytes aleatorios -> base32 -> UNIC-XXXXX-XXXXX-XXXXX-XXXXX
  const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
  const buf = crypto.randomBytes(15);
  let bits = 0, val = 0, out = '';
  for (const b of buf) { val = (val << 8) | b; bits += 8; while (bits >= 5) { out += A[(val >>> (bits - 5)) & 31]; bits -= 5; } }
  let grouped = '';
  for (let i = 0; i < out.length; i++) { if (i && i % 5 === 0) grouped += '-'; grouped += out[i]; }
  return 'UNIC-' + grouped;
}
function daysLeft(rec) { return Math.max(0, Math.ceil((rec.expiresAt - now()) / days(1))); }
function publicView(key, rec) {
  let status = 'ativa';
  if (rec.revoked) status = 'revogada';
  else if (now() > rec.expiresAt) status = 'expirada';
  else if (!rec.hwid) status = 'nao ativada';
  return {
    key, status,
    created: new Date(rec.created).toISOString(),
    expiresAt: new Date(rec.expiresAt).toISOString(),
    daysLeft: daysLeft(rec),
    hwid: rec.hwid || null,
    activatedAt: rec.activatedAt ? new Date(rec.activatedAt).toISOString() : null,
    note: rec.note || ''
  };
}

// ----------------------------------------------------------------------------
// HTTP helpers
// ----------------------------------------------------------------------------
function sendJson(res, code, obj) {
  const s = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' });
  res.end(s);
}
function readBody(req) {
  return new Promise((resolve) => {
    let data = '';
    req.on('data', (c) => { data += c; if (data.length > 1e6) req.destroy(); });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch (e) { resolve({}); } });
  });
}
function isAdmin(req) {
  const h = req.headers['authorization'] || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : h;
  // comparacao em tempo constante
  const a = Buffer.from(t); const b = Buffer.from(ADMIN_TOKEN);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// ----------------------------------------------------------------------------
// Logica de licenca
// ----------------------------------------------------------------------------
function doActivate(key, hwid) {
  const rec = DB.keys[key];
  if (!rec) return { ok: false, reason: 'chave inexistente' };
  if (rec.revoked) return { ok: false, reason: 'chave revogada' };
  if (now() > rec.expiresAt) return { ok: false, reason: 'chave expirada' };
  if (!hwid) return { ok: false, reason: 'hwid ausente' };
  if (rec.hwid && rec.hwid !== hwid) return { ok: false, reason: 'chave ja vinculada a outro dispositivo' };
  if (!rec.hwid) { rec.hwid = hwid; rec.activatedAt = now(); saveDB(); }
  return sign({ ok: true, expiresAt: rec.expiresAt, daysLeft: daysLeft(rec), ts: now() });
}
function doValidate(key, hwid) {
  const rec = DB.keys[key];
  if (!rec) return { ok: false, reason: 'chave inexistente' };
  if (rec.revoked) return { ok: false, reason: 'chave revogada' };
  if (now() > rec.expiresAt) return { ok: false, reason: 'chave expirada' };
  if (!rec.hwid) return { ok: false, reason: 'chave nao ativada' };
  if (rec.hwid !== hwid) return { ok: false, reason: 'dispositivo nao autorizado' };
  return sign({ ok: true, expiresAt: rec.expiresAt, daysLeft: daysLeft(rec), ts: now() });
}

// ----------------------------------------------------------------------------
// Roteamento
// ----------------------------------------------------------------------------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  const p = url.pathname;
  const method = req.method;

  if (method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type, Authorization', 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS' });
    return res.end();
  }

  // ---- API publica (usada pelo app) ----
  if (p === '/api/activate' && method === 'POST') {
    const b = await readBody(req);
    return sendJson(res, 200, doActivate(String(b.key || '').trim(), String(b.hwid || '').trim()));
  }
  if (p === '/api/validate' && method === 'POST') {
    const b = await readBody(req);
    return sendJson(res, 200, doValidate(String(b.key || '').trim(), String(b.hwid || '').trim()));
  }
  if (p === '/api/health') return sendJson(res, 200, { ok: true, keys: Object.keys(DB.keys).length });

  // ---- Painel admin (HTML) ----
  if (p === '/admin' && method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    return res.end(adminHtml());
  }

  // ---- API admin (protegida por token) ----
  if (p.startsWith('/admin/')) {
    if (!isAdmin(req)) return sendJson(res, 401, { ok: false, reason: 'nao autorizado' });

    if (p === '/admin/genkey' && method === 'POST') {
      const b = await readBody(req);
      const d = Math.max(1, parseInt(b.days || 30, 10));
      const count = Math.min(100, Math.max(1, parseInt(b.count || 1, 10)));
      const note = String(b.note || '');
      const created = [];
      for (let i = 0; i < count; i++) {
        let k; do { k = genKey(); } while (DB.keys[k]);
        DB.keys[k] = { created: now(), expiresAt: now() + days(d), hwid: null, activatedAt: null, revoked: false, note };
        created.push(k);
      }
      saveDB();
      return sendJson(res, 200, { ok: true, keys: created });
    }
    if (p === '/admin/list' && method === 'GET') {
      const arr = Object.entries(DB.keys).map(([k, r]) => publicView(k, r))
        .sort((a, b) => new Date(b.created) - new Date(a.created));
      return sendJson(res, 200, { ok: true, keys: arr });
    }
    if (p === '/admin/revoke' && method === 'POST') {
      const b = await readBody(req); const rec = DB.keys[String(b.key || '').trim()];
      if (!rec) return sendJson(res, 200, { ok: false, reason: 'chave inexistente' });
      rec.revoked = true; saveDB(); return sendJson(res, 200, { ok: true });
    }
    if (p === '/admin/unrevoke' && method === 'POST') {
      const b = await readBody(req); const rec = DB.keys[String(b.key || '').trim()];
      if (!rec) return sendJson(res, 200, { ok: false, reason: 'chave inexistente' });
      rec.revoked = false; saveDB(); return sendJson(res, 200, { ok: true });
    }
    if (p === '/admin/renew' && method === 'POST') {
      const b = await readBody(req); const rec = DB.keys[String(b.key || '').trim()];
      if (!rec) return sendJson(res, 200, { ok: false, reason: 'chave inexistente' });
      const d = Math.max(1, parseInt(b.days || 30, 10));
      const base = Math.max(now(), rec.expiresAt); // estende a partir de hoje ou do vencimento
      rec.expiresAt = base + days(d); saveDB();
      return sendJson(res, 200, { ok: true, expiresAt: new Date(rec.expiresAt).toISOString() });
    }
    if (p === '/admin/unbind' && method === 'POST') {
      const b = await readBody(req); const rec = DB.keys[String(b.key || '').trim()];
      if (!rec) return sendJson(res, 200, { ok: false, reason: 'chave inexistente' });
      rec.hwid = null; rec.activatedAt = null; saveDB(); // libera pra ativar em outro device
      return sendJson(res, 200, { ok: true });
    }
    if (p === '/admin/delete' && method === 'POST') {
      const b = await readBody(req); const k = String(b.key || '').trim();
      if (!DB.keys[k]) return sendJson(res, 200, { ok: false, reason: 'chave inexistente' });
      delete DB.keys[k]; saveDB(); return sendJson(res, 200, { ok: true });
    }
    return sendJson(res, 404, { ok: false, reason: 'rota admin inexistente' });
  }

  if (p === '/') { res.writeHead(302, { Location: '/admin' }); return res.end(); }
  sendJson(res, 404, { ok: false, reason: 'rota inexistente' });
});

server.listen(PORT, () => {
  console.log('=== Unic Client - Servidor de Licencas ===');
  console.log('Porta:        ' + PORT);
  console.log('Painel admin: http://localhost:' + PORT + '/admin');
  console.log('DB:           ' + DB_FILE);
  if (ADMIN_TOKEN === 'troque-este-token-admin') console.log('AVISO: defina ADMIN_TOKEN (env) antes de usar em producao!');
  if (SIGN_SECRET === 'troque-este-segredo-de-assinatura') console.log('AVISO: defina SIGN_SECRET (env) antes de usar em producao!');
});

// ----------------------------------------------------------------------------
// Painel admin (HTML embutido)
// ----------------------------------------------------------------------------
function adminHtml() {
  return `<!doctype html><html lang="pt-br"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Licencas - Admin</title>
<style>
*{box-sizing:border-box}body{margin:0;font-family:'Segoe UI',system-ui,sans-serif;background:#0f1115;color:#e6e8ec;padding:22px}
h1{font-size:20px;letter-spacing:2px;margin:0 0 14px}
.card{background:#171a21;border:1px solid #262b34;border-radius:14px;padding:18px;margin-bottom:16px;max-width:980px}
label{font-size:12px;color:#8b929c;display:block;margin:8px 0 4px}
input{padding:10px 12px;border:1px solid #2b313b;border-radius:9px;background:#0f1115;color:#e6e8ec;font-size:14px;outline:none}
button{padding:10px 16px;border:none;border-radius:9px;cursor:pointer;font-weight:600;color:#fff;background:#3a82f6;margin-right:6px}
button.g{background:#2b313b}button.r{background:#c0392b}button.y{background:#b8860b}
table{width:100%;border-collapse:collapse;font-size:13px;margin-top:10px}th,td{text-align:left;padding:7px 8px;border-bottom:1px solid #20242c}
th{color:#8b929c;font-weight:600}.mono{font-family:Consolas,monospace}
.s-ativa{color:#46d27e}.s-expirada{color:#e0a23b}.s-revogada{color:#e25555}.s-nao{color:#8b929c}
.row{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end}
pre{background:#0f1115;border:1px solid #262b34;border-radius:9px;padding:10px;white-space:pre-wrap;word-break:break-all}
small{color:#8b929c}
</style></head><body>
<h1>UNIC CLIENT &mdash; LICENCAS</h1>
<div class="card">
  <label>Token de admin</label>
  <div class="row"><input id="tok" type="password" placeholder="ADMIN_TOKEN" style="min-width:280px">
  <button onclick="save()">Salvar token</button><small id="who"></small></div>
</div>
<div class="card">
  <div class="row">
    <div><label>Dias de validade</label><input id="days" type="number" value="30" min="1" style="width:120px"></div>
    <div><label>Quantidade</label><input id="count" type="number" value="1" min="1" max="100" style="width:120px"></div>
    <div><label>Nota (opcional)</label><input id="note" type="text" placeholder="cliente / obs" style="width:220px"></div>
    <button onclick="gen()">Gerar chave(s)</button>
  </div>
  <pre id="genout" style="display:none"></pre>
</div>
<div class="card">
  <div class="row"><button class="g" onclick="load()">Atualizar lista</button><small id="msg"></small></div>
  <table id="tbl"><thead><tr><th>Chave</th><th>Status</th><th>Validade</th><th>Dias</th><th>HWID</th><th>Nota</th><th>Acoes</th></tr></thead><tbody></tbody></table>
</div>
<script>
const $=i=>document.getElementById(i);
function tok(){return localStorage.getItem('lic_tok')||'';}
function save(){localStorage.setItem('lic_tok',$('tok').value.trim());$('who').textContent='token salvo';load();}
async function api(path,method,body){
  const r=await fetch(path,{method:method||'GET',headers:{'Content-Type':'application/json','Authorization':'Bearer '+tok()},body:body?JSON.stringify(body):undefined});
  return r.json();
}
async function gen(){
  const j=await api('/admin/genkey','POST',{days:+$('days').value||30,count:+$('count').value||1,note:$('note').value});
  if(!j.ok){alert('Erro: '+(j.reason||'falhou'));return;}
  $('genout').style.display='block';$('genout').textContent=j.keys.join('\\n');load();
}
async function load(){
  const j=await api('/admin/list','GET');
  if(!j.ok){$('msg').textContent='Token invalido?';return;}
  $('msg').textContent=j.keys.length+' chave(s)';
  const tb=$('tbl').querySelector('tbody');tb.innerHTML='';
  j.keys.forEach(k=>{
    const tr=document.createElement('tr');
    const sc={ativa:'s-ativa',expirada:'s-expirada',revogada:'s-revogada','nao ativada':'s-nao'}[k.status]||'';
    tr.innerHTML='<td class=mono>'+k.key+'</td>'+
      '<td class="'+sc+'">'+k.status+'</td>'+
      '<td>'+k.expiresAt.slice(0,10)+'</td>'+
      '<td>'+k.daysLeft+'</td>'+
      '<td class=mono>'+(k.hwid||'-')+'</td>'+
      '<td>'+(k.note||'')+'</td>'+
      '<td></td>';
    const td=tr.lastChild;
    const mk=(label,cls,fn)=>{const b=document.createElement('button');b.textContent=label;if(cls)b.className=cls;b.style.padding='5px 9px';b.style.fontSize='12px';b.onclick=fn;td.appendChild(b);};
    if(k.status==='revogada') mk('Reativar','y',()=>act('/admin/unrevoke',k.key));
    else mk('Revogar','r',()=>act('/admin/revoke',k.key));
    mk('+30d','g',()=>act('/admin/renew',k.key,{days:30}));
    if(k.hwid) mk('Desvincular','g',()=>act('/admin/unbind',k.key));
    mk('Excluir','r',()=>{if(confirm('Excluir '+k.key+'?'))act('/admin/delete',k.key);});
    tb.appendChild(tr);
  });
}
async function act(path,key,extra){const j=await api(path,'POST',Object.assign({key},extra||{}));if(!j.ok)alert('Erro: '+(j.reason||'falhou'));load();}
$('tok').value=tok();if(tok())load();
</script></body></html>`;
}
