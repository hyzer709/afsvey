# Unic Client — Servidor de Licenças

Servidor próprio para gerenciar as keys (Node.js puro, **sem dependências**).
Faz: geração de chaves únicas, vínculo **1 device por key** (HWID), validação
automática, revogar/renovar/expirar, e um **painel admin** web.

## Rodar localmente

Precisa do Node.js 16+ instalado.

```bash
# defina um token de admin e um segredo de assinatura (troque os valores!)
set ADMIN_TOKEN=meu-token-secreto        # Windows (cmd)
set SIGN_SECRET=meu-segredo-de-assinatura
node server.js
```

No Linux/Mac:
```bash
ADMIN_TOKEN=meu-token-secreto SIGN_SECRET=meu-segredo-de-assinatura node server.js
```

Abra o painel: **http://localhost:8090/admin** e cole o `ADMIN_TOKEN` no campo do topo.

## Variáveis de ambiente

| Variável      | Padrão               | Para que serve                                  |
|---------------|----------------------|-------------------------------------------------|
| `PORT`        | `8090`               | Porta do servidor                               |
| `ADMIN_TOKEN` | (troque!)            | Senha do painel/admin                           |
| `SIGN_SECRET` | (troque!)            | Segredo que assina as respostas (HMAC)          |
| `DB_FILE`     | `./db.json`          | Onde guardar as licenças                        |

> **Importante:** defina `ADMIN_TOKEN` e `SIGN_SECRET` antes de usar pra valer.

## Endpoints

### Públicos (usados pelo app)
- `POST /api/activate`  body `{ "key": "...", "hwid": "..." }` → ativa e vincula o device.
- `POST /api/validate`  body `{ "key": "...", "hwid": "..." }` → revalida.
- `GET  /api/health` → status do servidor.

### Admin (header `Authorization: Bearer <ADMIN_TOKEN>`)
- `POST /admin/genkey`  `{ days, count, note }`
- `GET  /admin/list`
- `POST /admin/revoke`   `{ key }`
- `POST /admin/unrevoke` `{ key }`
- `POST /admin/renew`    `{ key, days }`
- `POST /admin/unbind`   `{ key }`  (libera a key pra outro device)
- `POST /admin/delete`   `{ key }`

## Hospedar de graça (resumo)

- **Render.com / Railway.app / Fly.io / Replit:** criar um serviço Node, comando
  de start `node server.js`, e definir as variáveis `ADMIN_TOKEN` e `SIGN_SECRET`.
- **Atenção à persistência:** em planos grátis o disco costuma ser efêmero
  (o `db.json` pode sumir em redeploys). Para produção, use um disco persistente
  do provedor ou troco o armazenamento por um banco (posso adaptar).

## Próximo passo (integração no app)

O app (`UnicClient.exe`) ainda valida localmente. O próximo passo é plugá-lo
neste servidor: na ativação ele manda `{key, hwid}` para `/api/activate`,
guarda o resultado e revalida em `/api/validate` periodicamente (com tolerância
offline). Basta me passar a URL pública onde o servidor vai ficar.
